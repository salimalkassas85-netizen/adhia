<?php $__env->startSection('content'); ?>
<div class="panel">
    <h1>تم استلام طلب هدية العيد</h1>
    <p>جزاك الله خيرًا على الثقة. سيُراجع فريق المبادرة الطلب بسرية وستر.</p>
    <p>رمز المتابعة: <strong><?php echo e($code); ?></strong></p>
    <p class="privacy">لا تعرض هذه الصفحة العنوان أو الموقع حفاظًا على الخصوصية.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\courses\adhia\resources\views/public/request-success.blade.php ENDPATH**/ ?>