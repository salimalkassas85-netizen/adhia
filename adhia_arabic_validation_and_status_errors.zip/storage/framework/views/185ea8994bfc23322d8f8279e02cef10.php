<?php $__env->startSection('content'); ?>
<div class="panel">
    <h1>طلب هدية العيد بسرية وستر</h1>
    <p class="privacy">بيانات موقعك تُستخدم فقط لتوصيل هدية العيد بواسطة فريق معتمد، ولا تظهر لأي شخص خارج فريق التوزيع.</p>
    <form method="post" action="<?php echo e(route('public.request.store')); ?>" id="gift-form">
        <?php echo csrf_field(); ?>
        <div class="grid grid-2">
            <div class="field"><label>الاسم الأول</label><input name="first_name" value="<?php echo e(old('first_name')); ?>" maxlength="50" required></div>
            <div class="field"><label>رقم الهاتف</label><input name="phone" value="<?php echo e(old('phone')); ?>" maxlength="20" required></div>
            <div class="field"><label>المنطقة</label><select name="area_id" required><option value="">اختر المنطقة</option><?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($area->id); ?>" <?php if(old('area_id') == $area->id): echo 'selected'; endif; ?>><?php echo e($area->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="field"><label>عدد أفراد الأسرة</label><input name="family_members_count" type="number" min="1" max="50" value="<?php echo e(old('family_members_count')); ?>"></div>
        </div>
        <div class="grid grid-2">
            <div class="field">
                <label>الحالة الاجتماعية</label>
                <select name="social_status">
                    <option value="">اختياري</option>
                    <?php $__currentLoopData = \App\Support\ArabicLabels::socialStatusOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($val); ?>" <?php if(old('social_status') == $val): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="grid grid-2">
            <label><input style="width:auto" type="checkbox" name="has_children" value="1" <?php if(old('has_children')): echo 'checked'; endif; ?>> يوجد أطفال</label>
            <label><input style="width:auto" type="checkbox" name="has_elderly" value="1" <?php if(old('has_elderly')): echo 'checked'; endif; ?>> يوجد كبار سن</label>
        </div>
        <div class="field"><label>العنوان الكامل</label><textarea name="full_address" required><?php echo e(old('full_address')); ?></textarea></div>
        <div class="field"><label>علامة قريبة</label><input name="landmark" value="<?php echo e(old('landmark')); ?>"></div>
        <input type="hidden" name="latitude" id="latitude" value="<?php echo e(old('latitude')); ?>">
        <input type="hidden" name="longitude" id="longitude" value="<?php echo e(old('longitude')); ?>">
        <input type="hidden" name="location_accuracy" id="location_accuracy" value="<?php echo e(old('location_accuracy')); ?>">
        <div class="field">
            <button type="button" class="btn secondary" id="locate-btn">تحديد موقعي الحالي</button>
            <p class="hint" id="location-message">لن يُطلب منك كتابة الإحداثيات. اضغط الزر ثم حرّك العلامة إذا احتجت لتعديل بسيط.</p>
        </div>
        <div id="map" class="map"></div>
        <div class="actions"><button type="submit">إرسال الطلب بأمان</button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('head'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIINfQxn1/BK0mXOWr8fhA0PTp7aN6fB0g=" crossorigin="">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
let map, marker;
const latInput = document.getElementById('latitude');
const lngInput = document.getElementById('longitude');
const accuracyInput = document.getElementById('location_accuracy');
const message = document.getElementById('location-message');

function setPosition(lat, lng, accuracy) {
    const position = [Number(lat), Number(lng)];
    latInput.value = position[0].toFixed(7);
    lngInput.value = position[1].toFixed(7);
    if (accuracy !== undefined && accuracy !== null) accuracyInput.value = Math.round(accuracy);

    if (!marker) {
        marker = L.marker(position, {draggable: true}).addTo(map);
        marker.on('dragend', () => {
            const p = marker.getLatLng();
            setPosition(p.lat, p.lng, accuracyInput.value);
        });
    } else {
        marker.setLatLng(position);
    }

    map.setView(position, 17);
}

function initMap() {
    const start = [Number(latInput.value || 21.4225), Number(lngInput.value || 39.8262)];
    map = L.map('map').setView(start, latInput.value ? 17 : 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap'
    }).addTo(map);
    if (latInput.value && lngInput.value) setPosition(latInput.value, lngInput.value, accuracyInput.value);
}

document.getElementById('locate-btn').addEventListener('click', () => {
    if (!navigator.geolocation) {
        message.textContent = 'المتصفح لا يدعم تحديد الموقع. جرّب من هاتفك أو متصفح حديث.';
        return;
    }
    message.textContent = 'جاري تحديد الموقع بأمان...';
    navigator.geolocation.getCurrentPosition((pos) => {
        setPosition(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy);
        message.textContent = 'تم تحديد الموقع. يمكنك تحريك العلامة على الخريطة لتدقيق نقطة التوصيل.';
    }, () => {
        message.textContent = 'تعذر تحديد الموقع. تأكد من السماح للمتصفح باستخدام الموقع.';
    }, {enableHighAccuracy: true, timeout: 15000});
});

document.getElementById('gift-form').addEventListener('submit', (event) => {
    if (!latInput.value || !lngInput.value) {
        event.preventDefault();
        message.textContent = 'يرجى تحديد موقع التوصيل قبل إرسال الطلب.';
        message.scrollIntoView({behavior: 'smooth', block: 'center'});
    }
});

initMap();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\courses\adhia\resources\views/public/request-gift.blade.php ENDPATH**/ ?>